import requests
import json
from flask import Flask, render_template, request

app = Flask(__name__)

def get_weather(city):
    api_key = "b27834f0c0f0b1eb7720d117f8b61033"
    base_url = "http://api.openweathermap.org/data/2.5/weather"

    params = {
        "q": city,
        "appid": api_key,
        "units": "metric"
    }

    try:
        response = requests.get(base_url, params=params)
        response.raise_for_status()  # Raise an exception if request fails
        weather_data = response.json()  # Convert response to JSON
        return weather_data
    except requests.exceptions.RequestException as err:
        error_message = f"An error occurred while fetching weather data: {err}"
        return {"error": error_message}
    except (KeyError, json.JSONDecodeError) as err:
        error_message = f"Failed to parse weather data: {err}"
        return {"error": error_message}
    
@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        city = request.form["city"]
        weather_data = get_weather(city)
        if "error" in weather_data:
            error_message = weather_data["error"]
            return render_template("error.html", error=error_message)
        return render_template("result.html", city=city, weather_data=weather_data)
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)